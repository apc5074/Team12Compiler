package helpers;

import java.util.HashMap;
import java.util.List;

import parserNodes.TypeNode;

public class SymTabs {
    public HashMap<String,TypeNode>  vSymTabl;
    public HashMap<String,List<TypeNode>> fSymTabl; 
}