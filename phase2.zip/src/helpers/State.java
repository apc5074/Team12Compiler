package helpers;

public enum State {
    START,
    COMMENT,
    ASSIGN,
    relOp,
    DOT,
    NUM,
    DIGIT,
    LETTER,
    COLON,
    EXPLIMATION,
    QUOTE
}